#!/system/bin/sh
# =============================================================
#  ScreenOff CoresOff v2.1 - service.sh
#  Offlines CPU cores (default 1..7) when the screen turns off,
#  restores them immediately when the screen turns back on.
#  KEEP_CORE (default 0) is NEVER touched - on most kernels
#  (including this Helio G85) cpu0 is the kernel boot CPU and
#  cannot be offlined anyway.
#
#  Screen-state sources (auto-selected, priority order):
#   1. backlight sysfs node            (fastest, ~250 ms poll)
#   2. dumpsys deviceidle get screen   (1 s poll - proven method,
#                                       used by Xtreme-Battery-Saver)
#   3. dumpsys power (mWakefulness)    (last resort)
#
#  v2.1: refused cores are RETRIED (3 passes) and the real kernel
#  error text is captured into the log (distinguishes transient
#  busy-refusals from genuine ones). Cores that fail to come back
#  online stay tracked and are retried on the next screen-on.
#
#  Startup diagnostics + every transition are logged to coreoff.log
# =============================================================

MODDIR="$(cd "$(dirname "$0")" && pwd)"
CONF="$MODDIR/coreoff.conf"
LOGF="$MODDIR/coreoff.log"

# ---------- defaults (overridable in coreoff.conf) ----------
CORES_OFF="1 2 3 4 5 6 7"
KEEP_CORE=0
OFF_THRESHOLD=1
POLL_SLEEP=0.25     # used when the backlight node source is active
DUMP_SLEEP=1        # used for the dumpsys sources
CONFIRM_SLEEP=0.3
BACKLIGHT_NODE=""

[ -f "$CONF" ] && . "$CONF"

log() { echo "$(date '+%F %T') $*" >> "$LOGF" 2>/dev/null; }

# ---------- wait for boot ----------
while [ "$(getprop sys.boot_completed 2>/dev/null)" != "1" ]; do
    sleep 1
done
log "=== module v2.1 (re)started ==="
log "CORES_OFF=[$CORES_OFF] KEEP_CORE=$KEEP_CORE OFF_THRESHOLD=$OFF_THRESHOLD"

# ---------- screen state sources ----------

# 1) backlight node
NODE=""
if [ -n "$BACKLIGHT_NODE" ] && [ -f "$BACKLIGHT_NODE/brightness" ]; then
    NODE="$BACKLIGHT_NODE/brightness"
else
    for d in /sys/class/backlight/*; do
        [ -f "$d/brightness" ] && { NODE="$d/brightness"; break; }
    done
fi

state_backlight() {
    [ -n "$NODE" ] || return 1
    v=$(cat "$NODE" 2>/dev/null) || v=""
    case "$v" in
        '' | *[!0-9]*) return 1 ;;
    esac
    if [ "$v" -le "$OFF_THRESHOLD" ]; then
        echo off
    else
        echo on
    fi
}

# 2) dumpsys deviceidle get screen -> "true" (on) / "false" (off)
state_deviceidle() {
    out=$(dumpsys deviceidle get screen 2>/dev/null | head -1)
    case "$out" in
        *true* | *ON*)   echo on;  return 0 ;;
        *false* | *OFF*) echo off; return 0 ;;
    esac
    return 1
}

# 3) dumpsys power -> mWakefulness= / Display Power: state=
state_power() {
    out=$(dumpsys power 2>/dev/null | grep -m1 -E 'mWakefulness=|Display Power: state=')
    case "$out" in
        *Awake* | *Dreaming*) echo on;  return 0 ;;
        *Asleep*)             echo off; return 0 ;;
        *state=ON*)           echo on;  return 0 ;;
        *state=OFF*)          echo off; return 0 ;;
    esac
    return 1
}

# ---------- pick source + startup diagnostics ----------
SRC=""
if [ -n "$NODE" ]; then
    SRC="backlight"
elif state_deviceidle >/dev/null 2>&1; then
    SRC="deviceidle"
elif state_power >/dev/null 2>&1; then
    SRC="power"
fi

log "backlight dir: [$(ls /sys/class/backlight/ 2>&1 | tr '\n' ' ')]"
log "diag 'dumpsys deviceidle get screen': [$(dumpsys deviceidle get screen 2>&1 | head -2 | tr '\n' ' ')]"
log "diag 'dumpsys power': [$(dumpsys power 2>/dev/null | grep -E 'mWakefulness=|Display Power: state=' | head -2 | tr '\n' ' ')]"

if [ -z "$SRC" ]; then
    log "FATAL: no usable screen-state source (no backlight node, dumpsys unusable)"
    log "manual check: su -c 'dumpsys deviceidle get screen'  and  su -c 'dumpsys power | grep mWakefulness'"
    exit 1
fi

log "screen-state source: $SRC  (poll: $POLL_SLEEP s if backlight else $DUMP_SLEEP s)"

get_state() {
    case "$SRC" in
        backlight)  state_backlight ;;
        deviceidle) state_deviceidle ;;
        power)      state_power ;;
    esac
}

log "screen state at start: [$(get_state 2>/dev/null)]"

# ---------- core hotplug ----------
OFFLINED=""
NO_NODES=""

# try to write val to cpu c's online node
# rc: 0 = ok, 1 = write/check failed, 2 = node missing
# on failure the shell's error text (if any) is captured in CAP_ERR
write_online() {
    c="$1"
    val="$2"
    n="/sys/devices/system/cpu/cpu$c/online"
    [ -f "$n" ] || return 2
    CAP_ERR=$( (echo "$val" > "$n") 2>&1 )
    sleep 0.1
    if [ "$(cat "$n" 2>/dev/null)" = "$val" ]; then
        return 0
    fi
    return 1
}

# is core c already handled (offlined, or has no node)?
handled() {
    case " $OFFLINED $NO_NODES " in
        *" $1 "*) return 0 ;;
    esac
    return 1
}

cores_offline() {
    local c pass rc pending
    for pass in 1 2 3; do
        for c in $CORES_OFF; do
            [ "$c" = "$KEEP_CORE" ] && continue
            handled "$c" && continue
            write_online "$c" 0
            rc=$?
            if [ "$rc" = "0" ]; then
                OFFLINED="$OFFLINED $c"
                if [ "$pass" = "1" ]; then
                    log "cpu$c -> OFFLINE"
                else
                    log "cpu$c -> OFFLINE (retry #$pass succeeded)"
                fi
            elif [ "$rc" = "2" ]; then
                log "cpu$c: no online node - skipped"
                NO_NODES="$NO_NODES $c"
            else
                log "cpu$c: offline refused (attempt $pass)${CAP_ERR:+ - $CAP_ERR}"
            fi
        done
        # all targets done? stop retrying
        pending=0
        for c in $CORES_OFF; do
            [ "$c" = "$KEEP_CORE" ] && continue
            handled "$c" || pending=1
        done
        [ "$pending" = "0" ] && break
        [ "$pass" = "3" ] && break
        sleep 1
    done
    log "screen-off done: OFFLINED=[$OFFLINED]"
}

cores_online() {
    [ -z "$OFFLINED" ] && return 0
    local c pass rc n new
    for pass in 1 2 3; do
        for c in $OFFLINED; do
            n="/sys/devices/system/cpu/cpu$c/online"
            # already back online (recovered in an earlier pass)
            [ "$(cat "$n" 2>/dev/null)" = "1" ] && continue
            write_online "$c" 1
            rc=$?
            if [ "$rc" = "0" ]; then
                if [ "$pass" = "1" ]; then
                    log "cpu$c -> ONLINE"
                else
                    log "cpu$c -> ONLINE (retry #$pass succeeded)"
                fi
            else
                log "cpu$c: online refused (attempt $pass)${CAP_ERR:+ - $CAP_ERR}"
            fi
        done
        # keep only cores that are STILL offline (stuck) so they get
        # retried on the next screen-on; drop the ones that recovered
        new=""
        for c in $OFFLINED; do
            n="/sys/devices/system/cpu/cpu$c/online"
            if [ "$(cat "$n" 2>/dev/null)" != "1" ]; then
                new="$new $c"
            fi
        done
        if [ -z "$new" ]; then
            break
        fi
        if [ "$pass" = "3" ]; then
            log "WARNING: cores STUCK OFFLINE after screen-on:[$new] - manual fix: su -c 'for c in $new; do echo 1 > /sys/devices/system/cpu/cpu\$c/online; done'"
            break
        fi
        sleep 1
    done
    OFFLINED="$new"
}

# ---------- main loop: poll -> debounce -> act ----------
prev=""
while :; do
    st=$(get_state)
    if [ -n "$st" ] && [ "$st" != "$prev" ]; then
        sleep "$CONFIRM_SLEEP"
        st2=$(get_state)
        if [ "$st2" = "$st" ]; then
            if [ "$st" = "off" ]; then
                cores_offline
            else
                cores_online
            fi
            prev="$st"
        fi
    elif [ -z "$prev" ]; then
        prev="$st"
    fi
    case "$SRC" in
        backlight) sleep "$POLL_SLEEP" ;;
        *)         sleep "$DUMP_SLEEP" ;;
    esac
done
