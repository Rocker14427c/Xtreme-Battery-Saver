#!/system/bin/sh
# Install-time diagnostics (harmless if any check is unavailable).
MODDIR="${0%/*}"
LOG="$MODDIR/install.log"
{
    echo "install check $(date '+%F %T')"
    for c in 0 1 2 3 4 5 6 7; do
        n="/sys/devices/system/cpu/cpu$c/online"
        if [ -w "$n" ]; then
            echo "cpu$c/online: writable"
        elif [ -f "$n" ]; then
            echo "cpu$c/online: exists but NOT writable (module will be no-op for this core)"
        else
            echo "cpu$c/online: missing"
        fi
    done
    echo "backlight nodes:"
    ls /sys/class/backlight/ 2>/dev/null
} > "$LOG" 2>&1
exit 0
