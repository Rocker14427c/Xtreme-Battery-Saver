#!/system/bin/sh
# Restore every core before the module is removed.
for c in 0 1 2 3 4 5 6 7 8 9 10 11; do
    n="/sys/devices/system/cpu/cpu$c/online"
    [ -f "$n" ] && echo 1 > "$n" 2>/dev/null
done
exit 0
