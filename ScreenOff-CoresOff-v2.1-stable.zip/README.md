# ScreenOff CoresOff (v2.1)

KernelSU module: when the screen turns **off**, CPU cores 1-7 are taken offline
(only core 0 stays active). When the screen turns **on**, all cores are restored
immediately. Core 0 is never touched.

## How it detects the screen (v2)

Automatically picks the first source that works on your device:

1. **Backlight sysfs node** (`/sys/class/backlight/*/brightness`) — fastest (~250 ms)
2. **`dumpsys deviceidle get screen`** — same method used by the popular
   Xtreme-Battery-Saver module; works on virtually all devices (~1 s poll)
3. **`dumpsys power`** (`mWakefulness=` / `Display Power: state=`) — last resort

At startup the module logs a **diagnostic block** showing what each source
returns on your device, plus which source it selected. If nothing works it
logs `FATAL: no usable screen-state source` and tells you which manual check
to run — so failures are diagnosable from the log alone.

## Install
1. Flash `ScreenOff-CoresOff.zip` via KernelSU Manager (Install → swipe).
   If it's rejected with a sepolicy error, delete `sepolicy.rule` and re-flash.
2. Reboot.
3. Check the log **right after boot** (diagnostic block):
   ```
   su -c 'head -15 /data/adb/modules/koff_coresoff/coreoff.log'
   ```
   Look for the line `screen-state source: deviceidle` (or backlight/power).

## Verify
Lock the screen for ~3 s, wake it, then:
```
su -c 'tail -25 /data/adb/modules/koff_coresoff/coreoff.log'
```
Expected: `cpu1..7 -> OFFLINE` (screen off), then `cpu1..7 -> ONLINE` (screen on),
with timestamps showing a ~1-2 s reaction.

Live state check (run before/after locking — see the log for what happened in between):
```
su -c 'cat /sys/devices/system/cpu/online'
```
→ `0` while the screen was off, `0-7` when back on.

## Configuration
Edit `/data/adb/modules/koff_coresoff/coreoff.conf` (see comments inside):
- `CORES_OFF` — which cores to offline (default 1-7)
- `KEEP_CORE` — core that must always stay on (default 0)
- `DUMP_SLEEP` — dumpsys poll interval (default 1 s; raise to 2-3 s to save a
  tiny bit of the module's own battery use)
- `BACKLIGHT_NODE` — force a specific backlight node if auto-detect is wrong

## Troubleshooting
- **`cpuN: offline refused (attempt X) - <error>`** → v2.1 retries refused
  cores up to 3 times (1 s apart) and logs the real kernel error.
  "Device or resource busy" that succeeds on retry = transient (a kernel
  thread was on that core at that moment). Refused on all 3 attempts = the
  kernel genuinely blocks that core; remove it from `CORES_OFF`.
- **`WARNING: cores STUCK OFFLINE`** → a core failed to come back online
  after 3 tries; the log includes the exact manual fix command. The module
  also auto-retries that core on the next screen-on.
- **Log says `screen-state source: power` or nothing worked** → the dumpsys
  source was blocked by SELinux. Try re-flashing; if sepolicy.rule is the
  culprit and your KSU rejects it, the module may still work because KernelSU's
  root domain usually has binder access — the diagnostic lines in the log show
  exactly which source returned usable output.
- **`cpu6: kernel REFUSED offline`** → your kernel pins the A75 big cores;
  remove `6 7` from `CORES_OFF` (they'll deep-sleep on their own when idle).
- **Device feels slow while screen is OFF** → remove some cores from `CORES_OFF`.
- **Nothing happens at all** → send the first ~15 log lines (diagnostic block)
  to the author.

## Battery expectation (honest)
Modern SoCs already put idle cores into deep sleep when the screen is off.
This module *guarantees* they are fully offline; the additional saving is
modest (typically a few mA).

## Restores happen automatically on
- Screen on (instant, ~1-2 s worst case with the dumpsys source)
- Reboot (kernel brings all cores back)
- Module uninstall (`uninstall.sh`)
